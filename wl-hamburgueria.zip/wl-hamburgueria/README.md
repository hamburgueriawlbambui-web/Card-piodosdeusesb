# WL Hambúrgueria dos Deuses — Cardápio Digital

Site estático (HTML/CSS/JS puro, sem build) com carrinho de pedidos e checkout via WhatsApp.

Número de WhatsApp configurado: **+55 37 99865-5709** (edite em `script.js`, constante `WHATSAPP_NUMBER`, se precisar trocar).

## Como publicar na Vercel

### Opção 1 — Arrastar e soltar (mais rápido, sem GitHub)
1. Acesse https://vercel.com e crie uma conta gratuita (pode entrar com Google/GitHub/e-mail).
2. No painel, clique em **Add New → Project**.
3. Escolha a aba **"Deploy without Git"** (ou arraste a pasta direto na área indicada).
4. Arraste a pasta `wl-hamburgueria` (com os arquivos `index.html`, `styles.css`, `script.js`) para a área de upload.
5. Clique em **Deploy**. Em segundos você recebe um link tipo `wl-hamburgueria.vercel.app`.

### Opção 2 — Pelo GitHub (recomendado se for atualizar depois)
1. Crie um repositório novo no GitHub e suba estes 3 arquivos (`index.html`, `styles.css`, `script.js`).
   - Pelo site do GitHub: **Add file → Upload files** e arraste os arquivos.
2. Entre em https://vercel.com → **Add New → Project**.
3. Clique em **Import Git Repository**, autorize o GitHub e selecione o repositório.
4. A Vercel detecta que é um site estático automaticamente — não precisa mudar nenhuma configuração (Framework Preset: "Other" está ok).
5. Clique em **Deploy**.
6. Pronto: toda vez que você atualizar o repositório no GitHub, a Vercel publica a nova versão sozinha.

### Opção 3 — Pela linha de comando (Vercel CLI)
Se tiver Node.js instalado no seu computador:
```bash
npm i -g vercel
cd wl-hamburgueria
vercel login
vercel --prod
```
Siga as perguntas no terminal (aceite os padrões) e o link de produção aparece no final.

## Domínio próprio (opcional)
Depois de publicado, em **Project → Settings → Domains** dá pra ligar um domínio próprio (ex: `cardapiowl.com.br`) apontando o DNS conforme a Vercel instrui.

## Testando localmente antes de publicar
Não precisa de nada instalado — é só abrir o `index.html` duas vezes (clique duplo) no navegador.
